<?php
$server="localhost";
$username="root";
$password="";
$db="lms";
$conn = mysqli_connect($server, $username, $password, $db);
if(!$conn){
    die('error' . mysqli_connect_errno());
}else{
    echo 'connected';
}
?>